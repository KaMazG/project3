﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project3
{
    /// <summary>
    /// Логика взаимодействия для EileraPage.xaml
    /// </summary>
    public partial class AdamsaPage : Page
    {
        public AdamsaPage()
        {
            InitializeComponent();
        }


        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            double h = double.Parse(HTextBox.Text);
            double x0 = double.Parse(X0TextBox.Text);
            double y0 = double.Parse(Y0TextBox.Text);
            double newY = 0;
            double newX = 0;
            List<double> yList = new List<double>() { y0 };
            List<double> xList = new List<double>() { x0 };
            for (int i = 0; i <= 3; i++)
            {
                newY = yList[i] + h * (Math.Pow(3 * xList[i], 2) + 2 * yList[i]);
                newX = xList[i] + h;
                yList.Add(newY);
                xList.Add(newX);
                MessageBox.Show($"y{i}: {yList[i]}");
            }
            for (int i = 4; i <= 10; i++)
            {
                double f1 = Math.Pow(3 * xList[i], 2) + 2 * yList[i] - yList[i-1];
                double f2 = Math.Pow(3 * xList[i], 2) + 2 * yList[i] - 2 * yList[i - 1] + yList[i-2];
                double f3 = Math.Pow(3 * xList[i], 2) + 2 * yList[i] - 3 * yList[i - 1] + 2 * yList[i - 2] - yList[i - 3]; ;

                newY = yList[i] + h* (Math.Pow(3 * xList[i], 2) + 2 * yList[i]) + (Math.Pow(h,2)/2) * f1 + (5*Math.Pow(h,3)/12) * f2 +(3*Math.Pow(h,4)/8)*f3;
                newX = xList[i] + h;
                yList.Add(newY);
                xList.Add(newX);
                MessageBox.Show($"y{i}: {yList[i]}");
            }
        }
    }
}
