﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project3
{
    /// <summary>
    /// Логика взаимодействия для EileraPage.xaml
    /// </summary>
    public partial class KutaPage : Page
    {
        public KutaPage()
        {
            InitializeComponent();
        }


        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            double h = double.Parse(HTextBox.Text);
            double x0 = double.Parse(X0TextBox.Text);
            double y0 = double.Parse(Y0TextBox.Text);
            double newY = 0;
            double newX = 0;
            List<double> yList = new List<double>() { y0 };
            List<double> xList = new List<double>() { x0 };
            for (int i = 0; i <= 10; i++)
            {
                double k1 = Math.Pow(3 * xList[i], 2) + 2 * yList[i];
                double k2 = Math.Pow(3 * xList[i], 2) + h / 2 + 2 * yList[i] + (h*k1)/2;
                double k3 = Math.Pow(3 * xList[i], 2) + h / 2 + 2 * yList[i] + (h * k2) / 2;
                double k4 = Math.Pow(3 * xList[i], 2) + h + 2 * yList[i] + h * k3;
                newY = (h / 6) * (k1 + 2*k2 + 2*k3 + k4);
                newX = xList[i] + h;
                yList.Add(newY);
                xList.Add(newX);
                MessageBox.Show($"y{i}: {yList[i]}");
            }
        }
    }
}
